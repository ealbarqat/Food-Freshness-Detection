import os
import shutil

# List of subdirectories to remove
subdirs = [
    'fresh_tomato',
    'fresh_orange',
    'fresh_capsicum',
    'fresh_bitter_gourd',
    'fresh_banana',
    'fresh_apple'
]

def remove_subdirs():
    for subdir in subdirs:
        if os.path.exists(subdir):
            try:
                shutil.rmtree(subdir)
                print(f"Removed directory: {subdir}")
            except Exception as e:
                print(f"Error removing {subdir}: {e}")
        else:
            print(f"Directory {subdir} does not exist")

if __name__ == "__main__":
    remove_subdirs() 