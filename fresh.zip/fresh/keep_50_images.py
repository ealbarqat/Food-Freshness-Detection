import os
import glob

# List of subdirectories
subdirs = [
    'fresh_tomato',
    'fresh_orange',
    'fresh_capsicum',
    'fresh_bitter_gourd',
    'fresh_banana',
    'fresh_apple'
]

def keep_50_images(directory):
    # Get all image files in the directory
    image_files = glob.glob(os.path.join(directory, '*.*'))
    image_files = [f for f in image_files if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
    
    # Sort files to ensure consistent selection
    image_files.sort()
    
    # Keep only the first 50 images
    if len(image_files) > 50:
        files_to_delete = image_files[50:]
        for file in files_to_delete:
            try:
                os.remove(file)
                print(f"Deleted: {file}")
            except Exception as e:
                print(f"Error deleting {file}: {e}")
        
        print(f"\nKept 50 images in {directory}")
        print(f"Deleted {len(files_to_delete)} images")
    else:
        print(f"\n{directory} already has {len(image_files)} images or fewer")

def main():
    for subdir in subdirs:
        if os.path.exists(subdir):
            print(f"\nProcessing {subdir}...")
            keep_50_images(subdir)
        else:
            print(f"\nDirectory {subdir} does not exist")

if __name__ == "__main__":
    main() 