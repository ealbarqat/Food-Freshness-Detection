import os
import glob
import shutil

# List of subdirectories
subdirs = [
    'fresh_tomato',
    'fresh_orange',
    'fresh_capsicum',
    'fresh_bitter_gourd',
    'fresh_banana',
    'fresh_apple'
]

def move_images_to_main(directory):
    # Get all image files in the directory
    image_files = glob.glob(os.path.join(directory, '*.*'))
    image_files = [f for f in image_files if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
    
    # Move each image to the main directory
    for file in image_files:
        try:
            # Get just the filename without the path
            filename = os.path.basename(file)
            # Create new filename with subdirectory prefix to avoid conflicts
            new_filename = f"{directory}_{filename}"
            # Move the file to main directory with new name
            shutil.move(file, new_filename)
            print(f"Moved: {file} -> {new_filename}")
        except Exception as e:
            print(f"Error moving {file}: {e}")
    
    print(f"\nMoved {len(image_files)} images from {directory}")

def main():
    for subdir in subdirs:
        if os.path.exists(subdir):
            print(f"\nProcessing {subdir}...")
            move_images_to_main(subdir)
        else:
            print(f"\nDirectory {subdir} does not exist")

if __name__ == "__main__":
    main() 